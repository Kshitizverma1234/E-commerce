// src/Dashboard.jsx

import React from 'react';
import './Dashboard.css'; // Import the CSS file for the dashboard

const products = [
  {
    id: 1,
    name: 'Product 1',
    image: 'https://via.placeholder.com/150', // Replace with actual image URLs
    price: '$19.99'
  },
  {
    id: 2,
    name: 'Product 2',
    image: 'https://via.placeholder.com/150',
    price: '$29.99'
  },
  {
    id: 3,
    name: 'Product 3',
    image: 'https://via.placeholder.com/150',
    price: '$39.99'
  },
  {
    id: 4,
    name: 'Product 4',
    image: 'https://via.placeholder.com/150',
    price: '$49.99'
  },
  // Add more products as needed
];

const Dashboard = () => {
  return (
    <div className="dashboard">
      {products.map(product => (
        <div className="product-card" key={product.id}>
          <img src={product.image} alt={product.name} className="product-image" />
          <div className="product-details">
            <h3 className="product-name">{product.name}</h3>
            <p className="product-price">{product.price}</p>
            <div className="product-actions">
              <button className="action-button add-to-cart">Add to Cart</button>
              <button className="action-button buy-now">Buy Now</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Dashboard;
