import React, { useState } from 'react';
import './Sidebar.css';
import { 
  FaBars, FaHome, FaTags, FaHeart, FaShoppingCart, FaUserCircle, 
  FaCreditCard, FaTruck, FaBell, FaGift, FaHeadset, FaSignOutAlt, 
  FaThLarge, FaMobileAlt, FaTshirt, FaHeartbeat, FaBaby, FaFutbol, 
  FaCrown, FaQuestionCircle, FaStore 
} from 'react-icons/fa';

const Sidebar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Function to toggle dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="sidebar">
      {/* Hamburger Icon to Toggle Dropdown */}
      <div className="hamburger-menu" onClick={toggleDropdown}>
        <FaBars className="module-ico" />
      </div>

      {/* Sidebar Menu */}
      <div className="sidebar-menu">
      <div className="sidebar-item">
          <FaHome className="module-icon" /> Home
        </div>
        <div className="sidebar-item">
          <FaTags className="module-icon" /> Today's Deals
        </div>
        <div className="sidebar-item">
          <FaHeart className="module-icon" /> Wish List
        </div>
        <div className="sidebar-item">
          <FaShoppingCart className="module-icon" /> Cart
        </div>
        <div className="sidebar-item">
          <FaCreditCard className="module-icon" /> Payment Options
        </div>
        <div className="sidebar-item">
          <FaTruck className="module-icon" /> Orders
        </div>
        <div className="sidebar-item">
          <FaBell className="module-icon" /> Notifications
        </div>
        <div className="sidebar-item">
          <FaGift className="module-icon" /> Gift Cards
        </div>
        <div className="sidebar-item">
          <FaUserCircle className="module-icon" /> Your Account
        </div>
        <div className="sidebar-item">
          <FaHeadset className="module-icon" /> Customer Service
        </div>
        <div className="sidebar-item">
          <FaThLarge className="module-icon" /> Categories
        </div>
        <div className="sidebar-item">
          <FaMobileAlt className="module-icon" /> Electronics
        </div>
        <div className="sidebar-item">
          <FaTshirt className="module-icon" /> Fashion
        </div>
        <div className="sidebar-item">
          <FaHeartbeat className="module-icon" /> Beauty & Health
        </div>
        <div className="sidebar-item">
          <FaBaby className="module-icon" /> Toys
        </div>
        <div className="sidebar-item">
          <FaFutbol className="module-icon" /> Sports
        </div>
        <div className="sidebar-item">
          <FaCrown className="module-icon" /> Prime
        </div>
        <div className="sidebar-item">
          <FaGift className="module-icon" /> Gift Finder
        </div>
        <div className="sidebar-item">
          <FaStore className="module-icon" /> Sell
        </div>
        <div className="sidebar-item">
          <FaQuestionCircle className="module-icon" /> Help
        </div>
        <div className="sidebar-item">
          <FaSignOutAlt className="module-icon" /> Sign Out
        </div>
        {/* Add more sidebar items here as needed */}
      </div>

      {/* Dropdown Menu */}
      <div className={`dropdown-menu ${isDropdownOpen ? 'show' : ''}`}>
        <div className="dropdown-item">
            <FaHome className="module-icon" /> Home
        </div>
        <div className="dropdown-item">
            <FaTags className="module-icon" /> Today's Deals
          </div>
          <div className="dropdown-item">
            <FaHeart className="module-icon" /> Wish List
          </div>
          <div className="dropdown-item">
            <FaShoppingCart className="module-icon" /> Cart
          </div>
          <div className="dropdown-item">
            <FaCreditCard className="module-icon" /> Payment Options
          </div>
          <div className="dropdown-item">
            <FaTruck className="module-icon" /> Orders
          </div>
          <div className="dropdown-item">
            <FaBell className="module-icon" /> Notifications
          </div>
          <div className="dropdown-item">
            <FaGift className="module-icon" /> Gift Cards
          </div>
          <div className="dropdown-item">
            <FaUserCircle className="module-icon" /> Your Account
          </div>
          <div className="dropdown-item">
            <FaHeadset className="module-icon" /> Customer Service
          </div>
          <div className="dropdown-item">
            <FaThLarge className="module-icon" /> Categories
          </div>
          <div className="dropdown-item">
            <FaMobileAlt className="module-icon" /> Electronics
          </div>
          <div className="dropdown-item">
            <FaTshirt className="module-icon" /> Fashion
          </div>
          <div className="dropdown-item">
            <FaHeartbeat className="module-icon" /> Beauty & Health
          </div>
          <div className="dropdown-item">
            <FaBaby className="module-icon" /> Toys
          </div>
          <div className="dropdown-item">
            <FaFutbol className="module-icon" /> Sports
          </div>
          <div className="dropdown-item">
            <FaCrown className="module-icon" /> Prime
          </div>
          <div className="dropdown-item">
            <FaGift className="module-icon" /> Gift Finder
          </div>
          <div className="dropdown-item">
            <FaStore className="module-icon" /> Sell
          </div>
          
          <div className="dropdown-item">
            <FaSignOutAlt className="module-icon" /> Sign Out
          </div>
        {/* Add more dropdown items here as needed */}
      </div>
    </div>
  );
};

export default Sidebar;
