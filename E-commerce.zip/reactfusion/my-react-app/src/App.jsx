import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard'; // Import the Dashboard component
import AuthPage from './AuthPage'; // Import the AuthPage component
import './App.css'; // Global CSS
import { FaSearch, FaLanguage, FaShoppingCart, FaTruck } from 'react-icons/fa'; // Import icons

const App = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([
    { id: 1, name: 'Product 1', quantity: 2 },
    { id: 2, name: 'Product 2', quantity: 1 },
  ]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showAuthPage, setShowAuthPage] = useState(false); // State for AuthPage visibility

  // Toggle cart visibility
  const toggleCart = () => {
    setCartOpen(!cartOpen);
  };

  // Calculate total orders
  const totalOrders = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Handle search box focus
  const handleSearchBoxFocus = () => {
    setDropdownOpen(true);
  };

  // Handle search box blur
  const handleSearchBoxBlur = () => {
    // Use a timeout to allow click events inside the dropdown to be processed
    setTimeout(() => setDropdownOpen(false), 200);
  };

  return (
    <div className="app">
      <Sidebar />
      <div className="main-content">
        <div className="navbar">
          <div className="navbar-left">
            <div className="website-name">Shayan</div>
            <div className="delivery-location">
              <FaTruck /> Deliver to: <span>Your Location</span>
            </div>
          {/* </div> */}
          <div className="search-box-container">
            <input
              type="text"
              placeholder="Search for products"
              className="search-box"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={handleSearchBoxFocus}
              onBlur={handleSearchBoxBlur}
            />
            <div className={`search-options-container ${dropdownOpen ? 'open' : ''}`}>
              <div className="search-option">All</div>
              <div className="search-option">Electronics</div>
              <div className="search-option">Fashion</div>
              <div className="search-option">Home</div>
            </div>
          </div>
          {/* <div className="navbar-right"> */}
            <FaLanguage className="icon" />
            {showAuthPage ? (
              <div className="auth-page" onClick={() => setShowAuthPage(false)}>Close Sign In</div>
            ) : (
              <div className="stylish-text" onClick={() => setShowAuthPage(true)}>Sign In</div>
            )}
            <div className="stylish-text"><retun>Returns</retun><b>& Orders</b></div>
            <div className="cart-icon" onClick={toggleCart}>
              <FaShoppingCart className="icon" />
              <span className="cart-text">Cart</span>
              <div className="cart-count">{totalOrders}</div>
            </div>
            {cartOpen && (
              <div className="cart-window">
                <h4>Cart</h4>
                {cartItems.map(item => (
                  <div className="cart-item" key={item.id}>
                    {item.name} - {item.quantity} <br />
                  </div>
                ))}
                <div className="cart-item-count">
                  Total Orders: {totalOrders}
                </div>
              </div>
            )}
          </div>
        </div>
        {showAuthPage ? (
          <div className="auth-page">
            <AuthPage onAuthSuccess={() => setShowAuthPage(false)} />
          </div>
        ) : (
          <Dashboard /> // Render Dashboard when not showing AuthPage
        )}
      </div>
    </div>
  );
};

export default App;
